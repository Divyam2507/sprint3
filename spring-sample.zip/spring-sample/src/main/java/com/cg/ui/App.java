package com.cg.ui;

import com.cg.service.CustomerService;
import com.cg.service.CustomerServiceImpl;

public class App {

	public static void main(String[] args) {
		CustomerService service = new CustomerServiceImpl();
		System.out.println(service.findAll().get(1).getFirstName());
	}

}
