package com.cg.repository;

import java.util.ArrayList;
import java.util.List;

import com.cg.model.Customer;

public class CustomerRepositoryImpl implements CustomerRepository {
	@Override
	public List<Customer> findAll(){
		List<Customer> customers = new ArrayList<>();
		
		Customer customer = new Customer();
		Customer customer1 = new Customer();
		customer.setFirstName("Divyam");
		customer.setLastName("Batta");
		
		customer1.setFirstName("karan");
		customer1.setLastName("singh");
		
		customers.add(customer);
		customers.add(customer1);
		
		return customers;
	}
	

}
