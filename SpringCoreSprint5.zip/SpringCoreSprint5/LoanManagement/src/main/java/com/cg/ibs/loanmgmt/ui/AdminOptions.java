package com.cg.ibs.loanmgmt.ui;

public enum AdminOptions {
	VERIFY_LOAN,VERIFY_PRECLOSURE,CHANGE_INTEREST_RATE,CHANGE_LOAN_LIMITS,LOG_OUT
}
