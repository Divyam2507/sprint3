package com.cg.ibs.loanmgmt.IBSexception;

public class IBSException extends Exception {
	public IBSException(String message) {
		super(message);
	}

}
